package com.example.demo.dto;

import java.util.List;

public class CategoryDTO {
    private Long id;
    private String name;
    private List<String> productNames;

   
}
