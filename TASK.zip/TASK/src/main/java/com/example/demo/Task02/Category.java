package com.example.demo.Task02;

public class Category {

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
