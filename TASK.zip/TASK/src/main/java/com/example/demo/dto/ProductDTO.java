package com.example.demo.dto;

public class ProductDTO {
    private Long id;
    private String name;
    private String categoryName;

  
}
